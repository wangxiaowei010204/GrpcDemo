﻿using System;

namespace GrpcLibrary
{
    public class Class1
    {
    }
}
